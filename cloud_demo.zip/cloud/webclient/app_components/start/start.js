(function() {
    'use strict';

    var startController = function() {
        var vm = this;
    };

    angular.module('redundancy')
        .controller('startController', [startController]);
}());