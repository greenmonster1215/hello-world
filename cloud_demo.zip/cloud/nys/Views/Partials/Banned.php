<h2>Banned</h2>
<div class="well">
<i class="fa fa-ban"></i> Your IP <?php echo $ip;?> has been blocked from this Redundancy Server. Contact the system administrator for unblocking.
</div>
<img class="branding" src="./nys/Views/img/logoWithTextSmall.png">